@echo off
title Tristinwold - change Telegram token
cd /d "%~dp0"
rem Forgets the saved bot token, then asks for a new one and starts the iPhone link.
reg delete HKCU\Environment /v TELEGRAM_BOT_TOKEN /f >nul 2>nul
set "TELEGRAM_BOT_TOKEN="
echo The old bot token is forgotten.
echo.
call "%~dp0Play from iPhone.bat"
