@echo off
title Tristinwold
cd /d "%~dp0"
rem The server gets its own window (pick its password there); this window goes on to the iPhone link.
start "Tristinwold server" "%~dp0Start Server.bat"
echo The server is starting in its own window: pick its password there.
echo.
call "%~dp0Play from iPhone.bat"
