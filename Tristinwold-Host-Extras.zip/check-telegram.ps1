# Checks the Telegram bot token and group before the game starts, so a bad token is asked for
# again right away. Exit codes: 0 fine, 1 couldn't reach Telegram, 2 bad token, 3 group problem.
$chat = $env:TELEGRAM_CHAT_ID
$m = [regex]::Match("$env:TELEGRAM_BOT_TOKEN", '\d{6,}:[A-Za-z0-9_-]{30,}')
if (-not $m.Success) {
    Write-Host "That isn't a bot token. In Telegram, open @BotFather, send /mybots, pick your bot,"
    Write-Host "then 'API Token', and copy the whole thing (it looks like 123456789:AAF...)."
    exit 2
}
$token = $m.Value
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try {
    $me = Invoke-RestMethod "https://api.telegram.org/bot$token/getMe" -TimeoutSec 15
} catch {
    $code = [int]$_.Exception.Response.StatusCode
    if ($code -eq 401 -or $code -eq 404) {
        Write-Host "Telegram doesn't recognise that token. Copy it again from @BotFather"
        Write-Host "(/mybots, your bot, 'API Token'). If you revoked it, use the new one."
        exit 2
    }
    Write-Host "Couldn't reach Telegram to check the token ($($_.Exception.Message)). Carrying on."
    exit 1
}
[Environment]::SetEnvironmentVariable('TELEGRAM_BOT_TOKEN', $token, 'User')
$bot = $me.result.username
Write-Host "Bot token OK: @$bot"
try {
    $c = Invoke-RestMethod "https://api.telegram.org/bot$token/getChat?chat_id=$chat" -TimeoutSec 15
    Write-Host "The iPhone link will be posted to: $($c.result.title)"
    exit 0
} catch {
    $body = "$($_.ErrorDetails.Message)"
    if ($body -match 'migrate_to_chat_id"?\s*:\s*(-?\d+)') {
        Write-Host "Your group became a supergroup (new ID $($Matches[1])); the game will post there."
        exit 0
    }
    Write-Host "@$bot can't see the group $chat yet. In Telegram, open the group, tap its name,"
    Write-Host "Add Members, and add @$bot. The game will start anyway; restart it once that's done."
    exit 3
}
