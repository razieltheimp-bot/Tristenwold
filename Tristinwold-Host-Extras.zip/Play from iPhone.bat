@echo off
title Tristinwold for iPhone
cd /d "%~dp0"
rem The Telegram group the iPhone link is posted to.
set "TELEGRAM_CHAT_ID=-5450084003"
:ask
if defined TELEGRAM_BOT_TOKEN goto check
echo To post the iPhone link to your Telegram group, paste your bot's token from @BotFather.
echo It looks like 123456789:AAF... (right-click pastes). It's kept in this PC's Windows
echo settings only, never in the game's files. Just press Enter to skip Telegram.
set "TELEGRAM_BOT_TOKEN="
set /p "TELEGRAM_BOT_TOKEN=Bot token: "
if not defined TELEGRAM_BOT_TOKEN goto token_done
:check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0check-telegram.ps1"
if errorlevel 2 if not errorlevel 3 (
  set "TELEGRAM_BOT_TOKEN="
  echo.
  goto ask
)
:token_done
set "CF=cloudflared"
set "CF86=%ProgramFiles(x86)%\cloudflared\cloudflared.exe"
set "CF64=%ProgramFiles%\cloudflared\cloudflared.exe"
where cloudflared >nul 2>nul && goto cf_ok
if exist "%CF86%" set "CF=%CF86%"
if exist "%CF64%" set "CF=%CF64%"
if not "%CF%"=="cloudflared" goto cf_ok
echo Installing Cloudflare's tunnel (cloudflared), just this once...
winget install --id Cloudflare.cloudflared -e --accept-source-agreements --accept-package-agreements
if exist "%CF86%" set "CF=%CF86%"
if exist "%CF64%" set "CF=%CF64%"
:cf_ok
echo.
echo Starting the game for your iPhone. Leave its window open (not minimised).
echo The link appears at the top of the game window and is posted to your Telegram group;
echo any problem with the tunnel or Telegram is shown there too.
start "" "%~dp0Tristinwold.exe" -- --remote --tunnel --cloudflared "%CF%" --login-server 127.0.0.1:7777
timeout /t 8
