@echo off
title Tristinwold server
echo The Rings of Tristinwold - shared world server
echo.
rem The server lives in a folder named server next to this file (the separate Tristinwold-Server-Windows.zip,
rem unzipped here), or next to this file itself, or in a sibling Tristinwold-Server-Windows folder.
set "HERE=%~dp0"
set "EXE="
for %%D in ("%HERE%server" "%HERE%." "%HERE%Tristinwold-Server-Windows" "%HERE%Tristinwold-Server-Windows\server" "%HERE%..\Tristinwold-Server-Windows" "%HERE%..\Tristinwold-Server-Windows\server") do (
  if not defined EXE if exist "%%~D\Tristinwold.Server.exe" set "EXE=%%~D\Tristinwold.Server.exe"
)
if not defined EXE (
  echo Tristinwold.Server.exe was not found.
  echo.
  echo The server is a separate download, Tristinwold-Server-Windows.zip. Unzip it so that
  echo   %HERE%server\Tristinwold.Server.exe
  echo exists ^(the zip already holds a folder named server: unzip it right here, next to Tristinwold.exe^),
  echo then run this again.
  echo.
  pause
  exit /b 1
)
for %%F in ("%EXE%") do cd /d "%%~dpF"
echo Found the server at %EXE%
echo The world is saved here, in tristinwold.json.
echo.
set /p PASS=Pick a password for your server (friends will need it; Enter for none): 
if "%PASS%"=="" goto nopass
"%EXE%" --password "%PASS%" --campaign tristinwold.json
goto done
:nopass
"%EXE%" --campaign tristinwold.json
:done
pause
